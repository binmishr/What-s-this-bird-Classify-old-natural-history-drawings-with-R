# Check ?plotmath for symbol math examples

img <- image_graph()
par(cex = 2)
example(plotmath)
dev.off()
print(img[4])
