library(testthat)
library(hocr)

test_check("hocr")
