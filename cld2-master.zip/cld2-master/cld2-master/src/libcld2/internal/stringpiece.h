

//
// A StringPiece points to part or all of a string, double-quoted string
// literal, or other string-like object.  A StringPiece does *not* own the
// string to which it points.  A StringPiece is not null-terminated. [subset]
//

#ifndef STRINGS_STRINGPIECE_H_
#define STRINGS_STRINGPIECE_H_

#include <string.h>
#include <string>


typedef int stringpiece_ssize_type;

class StringPiece {
 private:
  const char* ptr_;
  stringpiece_ssize_type length_;

 public:
  // We provide non-explicit singleton constructors so users can pass
  // in a "const char*" or a "string" wherever a "StringPiece" is
  // expected.
  StringPiece() : ptr_(NULL), length_(0) {}

  StringPiece(const char* str)  // NOLINT(runtime/explicit)
      : ptr_(str), length_(0) {
    if (str != NULL) {
      length_ = strlen(str);
    }
  }

  StringPiece(const std::string& str)  // NOLINT(runtime/explicit)
      : ptr_(str.data()), length_(0) {
    length_ = str.size();
  }

  StringPiece(const char* offset, stringpiece_ssize_type len)
      : ptr_(offset), length_(len) {
  }

  void remove_prefix(stringpiece_ssize_type n) {
    ptr_ += n;
    length_ -= n;
  }

  void remove_suffix(stringpiece_ssize_type n) {
    length_ -= n;
  }

  // data() may return a pointer to a buffer with embedded NULs, and the
  // returned buffer may or may not be null terminated.  Therefore it is
  // typically a mistake to pass data() to a routine that expects a NUL
  // terminated string.
  const char* data() const { return ptr_; }
  stringpiece_ssize_type size() const { return length_; }
  stringpiece_ssize_type length() const { return length_; }
  bool empty() const { return length_ == 0; }
};

class StringPiece;

#endif  // STRINGS_STRINGPIECE_H__
