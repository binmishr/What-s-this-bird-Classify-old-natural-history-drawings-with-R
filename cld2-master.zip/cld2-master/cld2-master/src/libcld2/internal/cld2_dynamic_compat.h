

#ifndef CLD2_INTERNAL_CLD2_DYNAMIC_COMPAT_H_
#define CLD2_INTERNAL_CLD2_DYNAMIC_COMPAT_H_



#ifdef _WIN32
  #include <io.h>
  #define OPEN _open
  #define CLOSE _close
#else // E.g., POSIX. We don't try to support Mac versions prior to OSX.
  #include <sys/mman.h>
  #include <fcntl.h>
  #include <unistd.h>
  #define OPEN open
  #define CLOSE close
#endif

#endif  // CLD2_INTERNAL_CLD2_DYNAMIC_COMPAT_H_
