

#include "base.h"

#include <string>
#ifdef _WIN32
#include <sstream>
#endif  // COMPILER_MSVC

namespace chrome_lang_id {

// TODO(abakalov): Pick the most efficient approach.
#ifdef _WIN32
std::string Int64ToString(int64 input) {
  std::stringstream stream;
  stream << input;
  return stream.str();
}
#else
std::string Int64ToString(int64 input) { return std::to_string(input); }
#endif  // COMPILER_MSVC

}  // namespace chrome_lang_id
