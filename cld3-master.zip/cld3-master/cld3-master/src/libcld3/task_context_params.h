

#ifndef TASK_CONTEXT_PARAMS_H_
#define TASK_CONTEXT_PARAMS_H_

#include <string>

#include "base.h"
#include "task_context.h"

namespace chrome_lang_id {

// Encapsulates the TaskContext specifying only the parameters for the model.
// The model weights are loaded statically.
class TaskContextParams {
 public:
  // Gets the name of the i'th language.
  static const char *language_names(int i) { return kLanguageNames[i]; }

  // Saves the parameters to the given TaskContext.
  static void ToTaskContext(TaskContext *context);

  // Gets the number of languages.
  static int GetNumLanguages();

 private:
  // Names of all the languages.
  static const char *const kLanguageNames[];

  // Features in FML format.
  static const char kLanguageIdentifierFeatures[];

  // Names of the embedding spaces.
  static const char kLanguageIdentifierEmbeddingNames[];

  // Dimensions of the embedding spaces.
  static const char kLanguageIdentifierEmbeddingDims[];
};
}  // namespace chrome_lang_id

#endif  // TASK_CONTEXT_PARAMS_H_
