
#ifndef RELEVANT_SCRIPT_FEATURE_H_
#define RELEVANT_SCRIPT_FEATURE_H_

#include "feature_extractor.h"
#include "cld_3/protos/sentence.pb.h"
#include "sentence_features.h"
#include "task_context.h"
#include "workspace.h"

namespace chrome_lang_id {

// Given a sentence, generates one FloatFeatureValue for each "relevant" Unicode
// script (see below): each such feature indicates the script and the ratio of
// UTF8 characters in that script, in the given sentence.
//
// What is a relevant script?  Recognizing all 100+ Unicode scripts would
// require too much code size and runtime.  Instead, we focus only on a few
// scripts that communicate a lot of language information: e.g., the use of
// Hiragana characters almost always indicates Japanese, so Hiragana is a
// "relevant" script for us.  The Latin script is used by dozens of language, so
// Latin is not relevant in this context.
class RelevantScriptFeature : public WholeSentenceFeature {
 public:
  void Setup(TaskContext *context) override;
  void Init(TaskContext *context) override;

  // Appends the features computed from the sentence to the feature vector.
  void Evaluate(const WorkspaceSet &workspaces, const Sentence &sentence,
                FeatureVector *result) const override;
};

}  // namespace chrome_lang_id

#endif  // RELEVANT_SCRIPT_FEATURE_H_
