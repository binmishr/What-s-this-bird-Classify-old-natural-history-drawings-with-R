
#include "embedding_feature_extractor.h"

#include <stddef.h>
#include <vector>

#include "feature_extractor.h"
#include "feature_types.h"
#include "task_context.h"
#include "utils.h"

namespace chrome_lang_id {

GenericEmbeddingFeatureExtractor::GenericEmbeddingFeatureExtractor() {}

GenericEmbeddingFeatureExtractor::~GenericEmbeddingFeatureExtractor() {}

void GenericEmbeddingFeatureExtractor::Setup(TaskContext *context) {
  // Don't use version to determine how to get feature FML.
  string features_param = ArgPrefix();
  features_param += "_features";
  const string features = context->Get(features_param, "");
  const string embedding_names =
      context->Get(GetParamName("embedding_names"), "");
  const string embedding_dims =
      context->Get(GetParamName("embedding_dims"), "");
  embedding_fml_ = utils::Split(features, ';');
  add_strings_ = context->Get(GetParamName("add_varlen_strings"), false);
  embedding_names_ = utils::Split(embedding_names, ';');
  for (const string &dim : utils::Split(embedding_dims, ';')) {
    embedding_dims_.push_back(utils::ParseUsing<int>(dim, utils::ParseInt32));
  }
}

void GenericEmbeddingFeatureExtractor::Init(TaskContext *context) {}

}  // namespace chrome_lang_id
