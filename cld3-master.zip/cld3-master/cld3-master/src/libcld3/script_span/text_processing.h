
#ifndef SCRIPT_SPAN_TEXT_PROCESSING_H_
#define SCRIPT_SPAN_TEXT_PROCESSING_H_

namespace chrome_lang_id {
namespace CLD2 {

// Remove portions of text that have a high density of spaces, or that are
// overly repetitive, squeezing the remaining text in-place to the front
// of the input buffer.
// Return the new, possibly-shorter length
int CheapSqueezeInplace(char *isrc, int srclen, int ichunksize);

}  // namespace CLD2
}  // namespace chrome_lang_id

#endif  // SCRIPT_SPAN_TEXT_PROCESSING_H_
