

#include "sentence_features.h"

#include "registry.h"

namespace chrome_lang_id {

// Declare registry for the whole Sentence feature functions.  NOTE: this is not
// yet set to anything meaningful.  It will be set so in NNetLanguageIdentifier
// constructor, *before* we use any feature.
template <>
WholeSentenceFeature::Registry
    *RegisterableClass<WholeSentenceFeature>::registry_ = nullptr;

}  // namespace chrome_lang_id
