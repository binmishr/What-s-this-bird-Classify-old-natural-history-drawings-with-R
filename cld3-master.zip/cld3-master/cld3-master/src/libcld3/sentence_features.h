
// Features that operate on Sentence objects. Most features are defined
// in this header so they may be re-used via composition into other more
// advanced feature classes.

#ifndef SENTENCE_FEATURES_H_
#define SENTENCE_FEATURES_H_

#include "feature_extractor.h"
#include "cld_3/protos/sentence.pb.h"

namespace chrome_lang_id {

// Feature function that extracts features for the full Sentence.
typedef FeatureFunction<Sentence> WholeSentenceFeature;

typedef FeatureExtractor<Sentence> WholeSentenceExtractor;

template <> WholeSentenceFeature::Registry
  *RegisterableClass<WholeSentenceFeature>::registry_;

}  // namespace chrome_lang_id

#endif  // SENTENCE_FEATURES_H_
