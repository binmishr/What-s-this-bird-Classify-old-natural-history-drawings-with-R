#' This function will return ClassificationBankIDs (hierarchiesIDs) that refer to the
#' given NamebankID
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @rdname ubio_classification_search-defunct
#' @export
#' @keywords internal 
#' @param ... Parameters, ignored
ubio_classification_search <- function(...) {
  .Defunct(msg = "the uBio API is down, for good as far as we know")
}
