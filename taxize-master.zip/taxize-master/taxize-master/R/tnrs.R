#' @title Phylotastic Taxonomic Name Resolution Service.
#' @description Defunct - service was down far too much to be reliable
#' @keywords internal 
#' @rdname tnrs-defunct
#' @export
#' @param ... ignored
tnrs <- function(...) {
  .Defunct(msg = "This function is defunct. See ?tnrs")
}
