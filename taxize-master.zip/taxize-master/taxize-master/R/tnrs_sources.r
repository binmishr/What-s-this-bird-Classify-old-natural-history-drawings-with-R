#' @title TNRS sources
#' @description Defunct - service was down far too much to be reliable
#' @keywords internal 
#' @rdname tnrs_sources-defunct
#' @export
#' @param ... ignored
tnrs_sources <- function(...) {
  .Defunct(msg = "This function is defunct. See ?tnrs_sources")
}
