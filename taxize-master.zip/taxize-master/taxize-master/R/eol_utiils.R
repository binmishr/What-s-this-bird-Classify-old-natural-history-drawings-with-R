eol_url <- function(x) sprintf('https://eol.org/api/%s/1.0', x)
