#' Search uBio for taxonomic synonyms by hierarchiesID.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @rdname ubio_synonyms-defunct
#' @export
#' @keywords internal
#' @param ... Parameters, ignored
ubio_synonyms <- function(...) {
  .Defunct(msg = "the uBio API is down, for good as far as we know, see `?taxize-defunct`")
}
