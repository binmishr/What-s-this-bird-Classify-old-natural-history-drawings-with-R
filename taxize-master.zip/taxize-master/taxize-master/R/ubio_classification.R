#' uBio classification
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @rdname ubio_classification-defunct
#' @export
#' @keywords internal
#' @param ... Parameters, ignored
ubio_classification <- function(...) {
  .Defunct(msg = "the uBio API is down, for good as far as we know")
}
