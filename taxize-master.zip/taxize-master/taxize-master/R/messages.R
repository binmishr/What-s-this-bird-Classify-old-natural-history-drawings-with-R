m_not_found_sp_altclass <-
"Not found. Consider checking the spelling or alternate classification"

m_more_than_one_found <-
"More than one %s found for taxon '%s'; refine query or set ask=TRUE"

m_na_ask_false <-
"NA due to ask=FALSE & > 1 result"

m_na_ask_false_no_direct <-
"NA due to ask=FALSE & no direct match found"
