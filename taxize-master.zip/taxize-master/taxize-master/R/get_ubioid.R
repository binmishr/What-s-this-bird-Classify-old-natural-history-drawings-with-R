#' Get the uBio id for a search term
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @rdname get_ubioid-defunct
#' @keywords internal
#' @export
get_ubioid <- function(...) .Defunct(msg = "the uBio API is gone")

#' @export
#' @rdname get_ubioid-defunct
as.ubioid <- function(...) .Defunct(msg = "the uBio API is gone")

#' @export
#' @rdname get_ubioid-defunct
get_ubioid_ <- function(...) .Defunct(msg = "the uBio API is gone")
